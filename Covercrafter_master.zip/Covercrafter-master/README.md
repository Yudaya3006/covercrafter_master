# Coverview
### [Project Link](https://covercrafter-ch.netlify.app/)
Crafting cover images for your blogs has become a breeze.


![cover (11)](https://github.com/Shivakumar1090/Covercrafter/assets/85950488/5897d350-a511-4218-a6bb-d14264195b5b)




 


## ⚡ Features
- 🚀 super fast and easy to use
- 🌈 4 different themes, multiple fonts
- 🌠 100+ dev icons with option to upload custom icon
- ✨ 15+ different background patterns

## 👩‍💻 Developing
This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).



```shell
git clone https://github.com/rutikwankhade/CoverView.git
cd CoverView/
npm start
```
